﻿#include <iostream>
#include <vector>
#include<cmath>

using namespace std;

long long determinant(vector< vector<long long> > &m) {
    
    long long det = 0;
    if (m.size() == 1)
        return m[0][0];
    if (m.size() == 2)
        return m[0][0] * m[1][1] - m[0][1] * m[1][0];

    for (size_t u = 0; u < m.size(); u++)
    {
        vector<vector <long long>> n_minor(m.size() - 1, vector<long long>(m.size() - 1, 0));
        size_t k = 0, l = 0;
        for (size_t i = 1; i < m.size(); i++)
        {
            for (size_t j = 0; j < m.size(); j++)
            {
                if (j != u)
                {
                    n_minor[l][k] = m[i][j];
                    k++;
                }
            }
            k = 0;
            l++;
        }
        det += pow(-1, u) * m[0][u] * determinant(n_minor);
    }
    return det;
}
int main()
{
    vector< vector<long long> > m = { {2, 5, 3} , {1, -2, -1}, {1, 3, 4} };
    cout << determinant(m) << endl;
    return 0;
}